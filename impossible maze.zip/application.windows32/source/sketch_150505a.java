import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_150505a extends PApplet {

//import ddf.minim.*;

//AudioPlayer player;
//Minim minim;//audio context

Actor r = new Actor(300, 200);
Maze maze [] = new Maze [80];

public void setup() {
  //minim = new Minim(this);
  //player = minim.loadFile("Impossible Maze SoundTrack (John).mp3", 2048);
  size(600,400);
  background(240,240,240);
  r.setColor(0,0,255);
  r.setPenColor(0, 0, 0);
  r.wid = 18;
  r.hei = 18;
  r.setDX(10);
  r.setDY(10);
  
  for (int i = 0; i < maze.length; i++)
     maze[i] = new Maze(); 
  } // end for
  

public void draw() {
  //player.play();
  background(240,240,240);
  fill(0xffFF0000);
  text("lives = " + r.lives, 8, 8);
  text("level: " + r.level, 490, 10);
  if (r.lives < 1) {
    textSize(60);
    text("game over", 200, 200);
  }
  for (int i = 0; i < maze.length; i++) {
    if (r.isTouching(maze[i])) {
      r.goTo(width/2, height/2);
      r.lives = r.lives - 1;
    }
  }
  
  r.drawEllipse();
  r.move();
  r.bounceEdge();
 
 for (int i = 0; i < maze.length; i++) {
    maze[i].act();
 }
 
 if (r.x < 0 || r.x > width || r.y < 0 || r.y > height) {
   r.goTo(width/2, height/2);
   r.level = r.level + 1;
  for (int i = 0; i < maze.length; i++)
     maze[i] = new Maze(); 
  } // end for
  
 }

//} //end draw 
class Actor {
  float x;
  float y;
  int fillRed = 0;
  int fillGreen = 0;
  int fillBlue = 0;
  int penRed = 0;
  int penGreen = 0;
  int penBlue = 0;
  int size = 50;
  int wid = 50;
  int hei = 50;
  int dx = 0;
  int dy = 0;
  int lives = 10;
  int level = 1;
  
  
  public Actor(float xPos, float yPos) {
    x = xPos;
    y = yPos;
  }
  public Actor() {
  }
  
  public void setColor(int r, int g, int b) {
    fillRed = r;
    fillGreen = g;
    fillBlue = b;
  }
  
  public void setPenColor(int r, int g, int b) {
    penRed = r;
    penGreen = g;
    penBlue = b;
  }
  
  public void move() {
    if (keyCode == TAB) {
        r.lives = 10;
        r.level = 0;
        textSize(12);
     }
    if (key == CODED) {
     if (keyCode == UP) {
      y = y - 4;
      x = x;
     } 
     if (keyCode == SHIFT) {
       r.lives = r.lives + 100;
     }
     if (keyCode == DOWN) {
      y = y + 4;
      x = x;
    } 
     if (keyCode == LEFT) {
       y = y;
       x = x - 4;
     }
     if (keyCode == RIGHT) {
       y = y;
       x = x + 4;
     }
    }
  }
  
  public void goTo(float xPos, float yPos) {
    x = xPos;
    y = yPos;
  }
  
  public void bounceEdge() {
    if (x > width || y < 0) {
      dx = dx * -1;
    }
    if (y > height || y < 0) {
      dy = dy * -1;
    }
  }
  
  public void setDX(int xVel) {
    dx = xVel;
  }
  
  public void setDY(int yVel) {
    dy = yVel;
  }
  
  public void drawRect() {
    stroke(penRed, penGreen, penBlue);
    fill(fillRed, fillGreen, fillBlue);
    rect(x, y, wid, hei);
  }
  
  public void drawEllipse() {
    stroke(penRed, penGreen, penBlue);
    fill(fillRed, fillGreen, fillBlue);
    ellipse(x, y, wid, hei);
  }
  
  public void drawTriangle() {
    stroke(penRed, penGreen, penBlue);
    fill(fillRed, fillGreen, fillBlue);
    triangle(x, y, x, y, x, y);    
  }
  
  public boolean isTouching(Actor a) {
    boolean xTouch = (x + wid/2 > a.x & x - wid/2 < a.x + a.wid);
    boolean yTouch = (y + hei/2 > a.y & y - hei/2 < a.y + a.hei);
    return (xTouch & yTouch);
  }
  
} //actor end here (maybe)
class Maze extends Actor {

  public Maze() {
    super();
    x = random(0, width);
    y = random(0, height);
    while(x > (width/2 - 25) & x < (width/2 + 25) & y > (height/2 - 25) & y < (height/2 +25)) {
          x = random(0, width);
          y = random(0, height);
    } //end while
    size = (int)random(5,10);
    wid = size;
    hei = size;
    fillBlue = 255;
    dy = (int)random(5,10);
  }
  
  public void drawMaze() {
    fill(fillRed, fillGreen, fillBlue);
    rect(x, y, hei, wid);
  }
  
  public void act() {
    drawMaze();
    if (y > height) {
      y = -20;
      dy = (int)random(1,10);
    }
  } 
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_150505a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
